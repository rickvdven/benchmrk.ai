# Update 9 voor Claude Code: social posts inplannen op Instagram en Facebook

Geef Claude Code deze opdracht:

> Lees `benchmrk-a-licht/CLAUDE_CODE_UPDATE_9_social_inplannen.md`. Bouw alles in één PR op een eigen branch ("social"). Zet de migratie klaar als SQL; die voer ik zelf uit in Supabase. Geef de Vercel-previewlink en screenshots van Admin → Social op 390 en 1440 breed. Niet mergen tot ik akkoord geef.

## Doel

De social agent maakt posts (carrousels, reels en losse beelden). Die komen als **concept** in een wachtrij in Benchmrk. Rick bekijkt ze in **Admin → Social**, past zo nodig tekst of tijd aan en keurt ze goed. Op het geplande tijdstip plaatst Benchmrk de post zelf op Instagram en/of de Facebookpagina via de Meta Graph API.

Harde regel: **niets gaat live zonder goedkeuring van een admin.** De social agent kan alleen concepten maken.

## 1. Migratie (volgend vrij nummer)

```sql
create table if not exists public.social_posts (
  id uuid primary key default gen_random_uuid(),
  status text not null default 'draft'
    check (status in ('draft','approved','processing','published','failed','rejected','cancelled')),
  platforms text[] not null default '{instagram}',          -- 'instagram', 'facebook'
  format text not null check (format in ('image','carousel','reel','story')),
  caption text not null default '' check (char_length(caption) <= 2200),
  media jsonb not null default '[]',                         -- [{ "path": "posts/<id>/1.jpg", "kind": "image"|"video" }], op volgorde
  cover_path text,                                           -- optionele cover voor een reel
  scheduled_at timestamptz,
  source text,                                               -- id uit de social agent, bv. 'w5b-2-rekensom'
  created_by text not null default 'admin',                  -- 'social-agent' of 'admin'
  approved_by uuid references auth.users,
  approved_at timestamptz,
  ig_container_id text,
  ig_media_id text,
  fb_post_id text,
  permalink text,
  attempts int not null default 0,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.social_posts enable row level security;
create policy "social_posts: admin" on public.social_posts
  for all using (public.is_admin()) with check (public.is_admin());
create index on public.social_posts (status, scheduled_at);
```

- **Opslag:** een **privé** bucket `social-media` (alleen service role). Meta krijgt bij het plaatsen een signed URL die 1 uur geldig is.
- **Cron elke 5 minuten via Supabase** (werkt ook op het gratis Vercel-plan, waar cron maar één keer per dag mag). Zet de SQL klaar met `pg_cron` en `pg_net`, die `POST https://app.benchmrk.ai/api/social/publish` aanroept met header `Authorization: Bearer <SOCIAL_CRON_SECRET>`. Het geheim zet Rick zelf in de SQL; zet in de briefing-SQL een placeholder `'<SOCIAL_CRON_SECRET>'`.

## 2. Omgevingsvariabelen (Vercel, Sensitive)

| Naam | Inhoud |
| --- | --- |
| `META_SYSTEM_USER_TOKEN` | Een **paginatoken** van de Facebookpagina dat niet verloopt (afgeleid van een long-lived user token). Gebruik het direct voor Instagram én Facebook; vraag geen apart paginatoken op. Werkt de code ook met een systeemgebruikertoken, dan is dat mooi meegenomen |
| `META_APP_SECRET` | App-geheim, voor `appsecret_proof` bij elke aanroep |
| `META_PAGE_ID` | ID van de Facebookpagina (mag eerst leeg; zie "Koppeling testen") |
| `META_IG_USER_ID` | ID van het Instagram-bedrijfsaccount (mag eerst leeg) |
| `SOCIAL_AGENT_TOKEN` | Lange willekeurige string voor de social agent (alleen concepten) |
| `SOCIAL_CRON_SECRET` | Lange willekeurige string voor de cron |

Zet de Graph API-versie als één constante in `server/_lib/meta.ts` (de huidige versie op het moment van bouwen). Voeg alles toe aan `.env.example` zonder waarden.

## 3. API voor de social agent: `server/social-agent.ts` → `/api/social/agent`

- Alleen met `Authorization: Bearer <SOCIAL_AGENT_TOKEN>` (vergelijken met `timingSafeEqual`). Anders 401.
- Maximaal 60 verzoeken per minuut.
- Acties (`POST`, JSON `{ action, ... }`):
  - `upload-url`: `{ postKey, n, mime }` → een signed upload-URL van Supabase Storage voor `posts/<postKey>/<n>.<ext>`. Alleen `image/jpeg` (Instagram accepteert alleen JPEG) en `video/mp4`. Maximaal 8 MB per beeld en 50 MB per video (limiet gratis Supabase-plan). De agent uploadt het bestand zelf direct naar die URL; zo gaat er geen groot bestand door de Vercel-functie.
  - `create`: `{ format, platforms, caption, media, cover_path?, scheduled_at?, source }` → maakt een regel met `status = 'draft'` en `created_by = 'social-agent'`. Controleer: de bestanden bestaan in de bucket, carrousel 2–10 items, reel precies 1 video, caption ≤ 2.200 tekens en ≤ 30 hashtags, tijdstip minstens 15 minuten in de toekomst. Bestaat `source` al als concept, dan wordt dat concept bijgewerkt in plaats van een nieuw aangemaakt.
  - `list`: de laatste 50 posts met `id, source, status, scheduled_at, permalink, last_error`. Geen andere velden.
  - `cancel`: `{ id }` → alleen als de status `draft` is.
- De agent kan **nooit** goedkeuren, plaatsen of iets wijzigen dat al goedgekeurd is.

## 4. Admin → Social (nieuw tabblad)

- **Lijst per week** (ma–zo, vorige/volgende), gesorteerd op tijdstip, plus een blok "Concepten zonder tijd". Per post: thumbnail, formaat, platforms, tijdstip (Europe/Amsterdam), status als badge, bron.
- **Detail / voorbeeld:**
  - carrousel als swipebare reeks, reel als videospeler (signed URLs), het bijschrift zoals het op Instagram oogt, met teller (tekens en hashtags);
  - bewerkbaar: bijschrift, tijdstip, platforms;
  - knoppen: **Goedkeuren** (zet `approved`, `approved_by`, `approved_at`), **Afwijzen**, **Nu plaatsen** (keurt goed met tijdstip nu), **Terugzetten naar concept** (alleen vóór plaatsing), **Annuleren**;
  - na plaatsing: link naar de post (`permalink`); bij een fout: `last_error` in gewone taal en een knop **Opnieuw proberen**.
- **Handmatig toevoegen:** een post maken door zelf beelden (JPEG/MP4) en tekst te uploaden. En **Pakket importeren**: een zip met `post.json` (zelfde velden als `create`) plus de bestanden. Zo kan het ook zonder de API van de agent.
- **Kopregel:** status van de koppeling ("Instagram en Facebook gekoppeld" of de fout) en "Nog X van de 100 posts over in 24 uur" (`content_publishing_limit`).
- **Koppeling testen:** een knop die met het token de pagina's en het gekoppelde Instagram-account ophaalt (`/me/accounts?fields=id,name,instagram_business_account{id,username}`) en de ID's toont, zodat Rick `META_PAGE_ID` en `META_IG_USER_ID` kan invullen. Toon nooit het token.
- Elke goedkeuring, plaatsing en annulering komt in `admin_audit_log` (update 8).
- Alle teksten in NL en EN; DE, ES en KO mogen de EN-tekst gebruiken, maar er mogen geen keys ontbreken.

## 5. Plaatsen: `server/social-publish.ts` → `/api/social/publish`

Alleen met `Bearer <SOCIAL_CRON_SECRET>` (of vanaf de admin-knop "Nu plaatsen", met een admin-JWT). Per aanroep:

1. **Pak posts op** met `status = 'approved' and scheduled_at <= now()`, atomisch (`update … set status = 'processing' … returning`), zodat een post nooit twee keer geplaatst wordt. Maximaal 5 per aanroep.
2. **Instagram** (`graph.facebook.com`, met `appsecret_proof`):
   - controleer eerst `GET /{ig-user-id}/content_publishing_limit`;
   - **image:** `POST /{ig-user-id}/media` met `image_url`;
   - **carousel:** per item een container met `is_carousel_item=true` (`image_url`, of `video_url` met `media_type=VIDEO`), dan een container met `media_type=CAROUSEL`, `children` en `caption`;
   - **reel:** `media_type=REELS`, `video_url`, `caption`, `share_to_feed=true`, eventueel `cover_url`;
   - **story:** `media_type=STORIES` met `image_url` of `video_url`;
   - sla `ig_container_id` op. Is `GET /{container}?fields=status_code` nog `IN_PROGRESS`, laat de post dan op `processing` staan; de volgende cronronde kijkt opnieuw. Bij `FINISHED`: `POST /{ig-user-id}/media_publish` met `creation_id`, haal daarna `permalink` op. Bij `ERROR` of `EXPIRED`: fout.
3. **Facebook** (als `facebook` in `platforms`): beeld via `POST /{page-id}/photos`; carrousel als meerdere niet-gepubliceerde foto's en daarna `POST /{page-id}/feed` met `attached_media`; reel via de Reels-API van de pagina (`/{page-id}/video_reels`, upload in fases volgens de Video API-documentatie). Het token in `META_SYSTEM_USER_TOKEN` is al een paginatoken. Stories alleen op Instagram.
4. **Status:** beide gelukt → `published`. Een fout → `attempts + 1` en `last_error`; terug naar `approved` met `scheduled_at = now() + 10 min`, tot 3 pogingen, daarna `failed`. Is één platform al gelukt, plaats dat niet opnieuw (houd `ig_media_id` / `fb_post_id` aan).
5. **Mail** naar info@benchmrk.ai bij `failed`, met de post (bron, tijdstip) en de fout. Geen mail bij succes.
6. **Dagelijkse controle** in de bestaande cron: `GET /debug_token`. Is het token ongeldig of mist het rechten, mail dan info@benchmrk.ai en toon het in Admin → Social.

## 6. Beveiliging

- Het Meta-token staat alleen in Vercel en wordt nooit naar de browser gestuurd, gelogd of in een fout getoond (filter het uit foutteksten van Meta).
- `social_posts` en de bucket zijn alleen voor admins en de service role.
- Het agent-token kan alleen concepten maken; te roteren door de env var te vervangen.
- Voeg aan de CSP (update 8) niets toe voor Meta: alle aanroepen naar Meta lopen via de server.
- Signed URL's voor Meta zijn hooguit 1 uur geldig.

## 7. Tests

- Agent-API: zonder token 401; `create` levert altijd `draft`; een agent kan niet goedkeuren of een goedgekeurde post wijzigen; validatie (aantal items, JPEG, caption-lengte, tijdstip).
- Publisher met een gemockte Graph API: image, carousel, reel (eerst `IN_PROGRESS`, dan `FINISHED` in de volgende ronde), Facebook mislukt maar Instagram gelukt → Instagram wordt niet opnieuw geplaatst, 3 fouten → `failed` + mail.
- Een post wordt nooit dubbel opgepakt bij twee gelijktijdige aanroepen.
- Het token komt in geen enkele response of log voor.

## Controle

- Typecheck, tests, `npm run test:db`, `build:api` en build slagen.
- Op de preview: "Koppeling testen" toont de pagina en het Instagram-account.
- Plan één testpost (een beeld, alleen Instagram) 20 minuten vooruit, keur goed en controleer dat hij verschijnt met de juiste tekst. Verwijder hem daarna zelf in Instagram.
- Daarna één carrousel en één reel.

## Niet doen

- Niets automatisch goedkeuren of plaatsen zonder admin.
- Geen persoonsgegevens van gebruikers in posts of logs.
- Geen reacties of DM's lezen; alleen plaatsen.
- Niet mergen zonder akkoord van Rick.
